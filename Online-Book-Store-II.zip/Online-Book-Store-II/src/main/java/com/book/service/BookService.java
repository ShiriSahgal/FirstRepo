package com.book.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.book.entity.Book;
import com.book.repository.BookRepository;

@Service
public class BookService {
	@Autowired
	private BookRepository bookRepository;
	
	public Book addNewBook(Book book) {
		Book b = bookRepository.save(book);
		return b;
	}
	
	public List<Book> getAllBooks(){
		return (List<Book>) bookRepository.findAll();
	}
	
	
	public void deleteBookDetails(Integer bookId) {
		bookRepository.deleteById(bookId);
	}
	
	public Book getBookDetailsById(Integer bookId) {
		
		return bookRepository.findById(bookId).get();
	}

}
