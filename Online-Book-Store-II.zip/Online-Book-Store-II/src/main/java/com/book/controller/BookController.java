package com.book.controller;

import java.io.IOException;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.book.entity.Book;
import com.book.entity.ImageModel;
import com.book.service.BookService;

@RestController
@CrossOrigin(origins="https://localhost:4200")

public class BookController {
	@Autowired
	private BookService bookService;
	
//	@PostMapping("/addNewBook")
//	public Book addNewBook(@RequestBody Book book) {
//		return bookService.addNewBook(book);
//		
//	}
	
	@PostMapping(value={"/addNewBook"},consumes= {MediaType.MULTIPART_FORM_DATA_VALUE })
	public Book addNewBook(@RequestPart("book") Book book , @RequestPart("imageFile")MultipartFile[] file) {
//		return bookService.addNewBook(book);
		try {
			
		Set<ImageModel> images =  uploadImage(file);
		book.setBookImages(images);
		return bookService.addNewBook(book);
		
	}catch(Exception e) {
		System.out.println(e.getMessage());
		return null;
		
	}
		
	}
	
	public Set<ImageModel> uploadImage(MultipartFile[] multipartFiles) throws IOException {
		Set<ImageModel> imageModels = new HashSet<>();
		for(MultipartFile file:multipartFiles) {
			ImageModel imageModel = new ImageModel(
					file.getOriginalFilename(),
					file.getContentType(),
					file.getBytes()
					);
			imageModels.add(imageModel);
		}
		
		return imageModels;
	}
	
	@GetMapping("/getAllBooks")
	public List<Book> getAllBooks(){
		return bookService.getAllBooks();
		
	}
	
	
	@DeleteMapping({"/deleteBookDetails/{bookId}"})
	public void deleteBookDetails(@PathVariable("bookId") Integer bookId) {
		bookService.deleteBookDetails(bookId);
		
	}
	
	@GetMapping({"/getBookDetailsById/{bookId}"})
	public Book getBookDetailsById(@PathVariable("bookId") Integer bookId) {
		return bookService.getBookDetailsById(bookId);
		
	}
	
	
	
	

}
