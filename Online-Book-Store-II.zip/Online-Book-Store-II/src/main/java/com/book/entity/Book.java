package com.book.entity;

import java.util.Set;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Book{
@Id
@GeneratedValue(strategy=GenerationType.AUTO)
private Integer bookId;

private String bookTitle;

private String bookDescription;

private String bookAuthor;

private Double bookPrice;



@ManyToMany(fetch=FetchType.EAGER,cascade=CascadeType.ALL)
@JoinTable(name="book_images",
		joinColumns= {
				@JoinColumn(name="book_id")
		},
		inverseJoinColumns= {
				@JoinColumn(name="image_id")
		}
		)
private Set<ImageModel> bookImages;


}
