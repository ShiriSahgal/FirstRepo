package com.book.Online.Book.Store.II;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineBookStoreIiApplicationTests {

	@Test
	void contextLoads() {
	}

}
