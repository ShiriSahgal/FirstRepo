import { Component } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {

  
    isLogged=false;
    username!: string; // Property to store the username
    password!: string; // Property to store the password
  
    constructor(private router:Router) { }
  
    admin() {
      // Access the username and password here
      if((this.username=='admin')&& (this.password=='admin')){
        this.router.navigateByUrl('/header'); 
        console.log(this.username);
        console.log(this.password);
        this.isLogged=true;
      }
      else{
        alert("WRONG CREDENTIALS");
        console.log(this.username);
        console.log(this.password);
        this.isLogged=false;
      }
  
      // You can perform further actions like sending the data to a server, etc.
    }
  }
  


