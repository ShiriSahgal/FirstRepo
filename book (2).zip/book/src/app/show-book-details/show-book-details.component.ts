import { Component, OnInit } from '@angular/core';
import { BookService } from '../_services/book.service';
import { Book } from '../_model/book.model';
import { HttpErrorResponse } from '@angular/common/http';
import { ImageProcessingService } from '../_services/image-processing.service';
import { map } from 'rxjs';
import { Router } from '@angular/router';

@Component({
  selector: 'app-show-book-details',
  templateUrl: './show-book-details.component.html',
  styleUrl: './show-book-details.component.css'
})
export class ShowBookDetailsComponent implements OnInit{
  loopArray = new Array(20);
  bookDetails:Book[]=[];

  constructor(private bookService: BookService,
    private imageProcessingService:ImageProcessingService,
    private router:Router
  ){}
  ngOnInit(): void {
    this.getAllBooks();
  }


  public getAllBooks(){
    this.bookService.getAllBooks()
    .pipe(
      map((x: Book[], i:any) => x.map((book:Book) => this.imageProcessingService.createImages(book)))
    ).subscribe(
      (response:Book[])=>{
        console.log(response);
        response.forEach((book, index) => {
          console.log(this.showBooks(book));
        });
        this.bookDetails=response;
      },
      (error:HttpErrorResponse)=>{
        console.log(error);

      }
    )
  }



  deleteBook(bookId:number){
    console.log(bookId);
    this.bookService.deleteBook(bookId).subscribe(
      (response:any)=>{
        console.log(response);
        this.getAllBooks();
      },
      (error:HttpErrorResponse)=>{
        console.log(error);
      }
    );
  }

  showBooks(book:Book){
    console.log(book);
  }

  editBookDetails(bookId:number){
    console.log(bookId);
    this.router.navigate(['/addNewBook',{bookId:bookId}])

  }
}
