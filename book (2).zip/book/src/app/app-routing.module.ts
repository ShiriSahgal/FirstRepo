import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { AddNewBookComponent } from './add-new-book/add-new-book.component';
import { ShowBookDetailsComponent } from './show-book-details/show-book-details.component';
import { BookResolverService } from './_services/book-resolver.service';
import { HeaderComponent } from './header/header.component';
import { LoginComponent } from './login/login.component';

const routes: Routes = [
  {path:'header',component:HeaderComponent},
  {path:'',component:LoginComponent},
  {path:'addNewBook',component:AddNewBookComponent,
    resolve:{
      book:BookResolverService
    }
  },
  {path:'showBookDetails',component:ShowBookDetailsComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
