import { FileHandle } from "./file-handle.model"

export interface Book{
    bookId:number,
    bookTitle:string,
    bookAuthor:string,
    bookDescription:string,
    bookPrice:number
    bookImages:FileHandle[]
}