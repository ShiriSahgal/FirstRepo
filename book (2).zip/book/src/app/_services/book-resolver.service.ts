import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, MaybeAsync, Resolve, RouterStateSnapshot } from '@angular/router';
import { Book } from '../_model/book.model';
import { Observable, map, of } from 'rxjs';
import { BookService } from './book.service';
import { ImageProcessingService } from './image-processing.service';

@Injectable({
  providedIn: 'root'
})
export class BookResolverService implements Resolve<Book>{

  constructor(private bookService:BookService,
    private imageProcessingService: ImageProcessingService
  ) { }
  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<Book> {
    const id=route.paramMap.get("bookId");

    if(id){
      return this.bookService.getBookDetailsById(id)
      .pipe(map(p=>this.imageProcessingService.createImages(p)));
    }else{
      return of(this.getProductDetails());
    }
  }

  getProductDetails(){
    return{
      
        bookId:0,
        bookTitle:"",
        bookAuthor:"",
        bookDescription:"",
        bookPrice:0,
        bookImages:[]
      
    }
  }
}
