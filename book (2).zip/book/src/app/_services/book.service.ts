import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Book } from '../_model/book.model';

@Injectable({
  providedIn: 'root'
})
export class BookService {

  constructor(private httpClient:HttpClient) { }

  public addBook(book:FormData){
    return this.httpClient.post<Book>("http://localhost:8080/addNewBook",book);
  }

  public getAllBooks(){
    return this.httpClient.get<Book[]>("http://localhost:8080/getAllBooks");
  }

  public getBookDetailsById(bookId:any){
    return this.httpClient.get<Book>("http://localhost:8080/getBookDetailsById/"+bookId);

  }

  public deleteBook(bookId:number){
    return this.httpClient.delete("http://localhost:8080/deleteBookDetails/"+bookId);
  }
}
