import { Component, OnInit } from '@angular/core';
import { Book } from '../_model/book.model';
import { NgForm } from '@angular/forms';
import { BookService } from '../_services/book.service';
import { HttpErrorResponse } from '@angular/common/http';
import { FileHandle } from '../_model/file-handle.model';
import { DomSanitizer } from '@angular/platform-browser';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-add-new-book',
  templateUrl: './add-new-book.component.html',
  styleUrl: './add-new-book.component.css'
})
export class AddNewBookComponent implements OnInit{
  isNewBook = true;
  book:Book={
    bookId:0,
    bookTitle:"",
    bookAuthor:"",
    bookDescription:"",
    bookPrice:0,
    bookImages:[]
  }
  bookForm: any;

  constructor(private bookService:BookService,
    private sanitizer:DomSanitizer,
    private activatedRoute : ActivatedRoute
  ){}
  ngOnInit(): void {

  
    this.book = this.activatedRoute.snapshot.data['book'];
    if((this.book&&this.book.bookId)){
      this.isNewBook=false;
    }
  }
  addBook(bookForm:NgForm){
    
    console.log(bookForm.value);
    const bookFormData = this.prepareFormData(this.book);
    this.bookService.addBook(bookFormData).subscribe(
      (response:Book)=>{
        console.log(response);
      },
      (error:HttpErrorResponse)=>{
        console.log(error);
      }
    );
    console.log("Hello");
  }

 
  prepareFormData(book:Book):FormData{
    const formData = new FormData();

    formData.append(
      'book',
      new Blob([JSON.stringify(book)],{type:'application/json'})
    );
    for(var i=0;i<book.bookImages.length;i++){
      formData.append(
        'imageFile',
        book.bookImages[i].file,
        book.bookImages[i].file.name
      );
    }
    return formData;
  }


  onFileSelected(event: any){
    if(event.target.files){
      const file = event.target.files[0];


      const fileHandle:FileHandle={
        file:file,
        url: this.sanitizer.bypassSecurityTrustUrl(window.URL.createObjectURL(file))
      }

      this.book.bookImages.push(fileHandle);
    }
  }

  removeImages(i:number){
    this.book.bookImages.splice(i,1);
  }

 
}
